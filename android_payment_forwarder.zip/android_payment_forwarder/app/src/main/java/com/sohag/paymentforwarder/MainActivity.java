package com.sohag.paymentforwarder;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText urlInput;
    private EditText secretInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestSmsPermission();

        SharedPreferences prefs = getSharedPreferences(PaymentForwarder.PREFS, MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 36, 36, 36);

        TextView title = new TextView(this);
        title.setText("Payment Forwarder");
        title.setTextSize(22);
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Set the central gateway URL and your App Secret from the payment dashboard.");
        hint.setPadding(0, 16, 0, 16);
        root.addView(hint);

        urlInput = new EditText(this);
        urlInput.setHint("http://YOUR_SERVER_IP:8790/sms");
        urlInput.setSingleLine(true);
        urlInput.setText(prefs.getString(PaymentForwarder.KEY_URL, ""));
        root.addView(urlInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        secretInput = new EditText(this);
        secretInput.setHint("Bridge Secret");
        secretInput.setSingleLine(true);
        secretInput.setText(prefs.getString(PaymentForwarder.KEY_SECRET, ""));
        root.addView(secretInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button save = new Button(this);
        save.setText("Save Settings");
        save.setOnClickListener(v -> saveSettings());
        root.addView(save);

        Button test = new Button(this);
        test.setText("Send Test Payment SMS");
        test.setOnClickListener(v -> {
            saveSettings();
            PaymentForwarder.send(this, "bKash", "You have received Tk 120.00. TrxID ABC123XYZ.");
            Toast.makeText(this, "Test sent", Toast.LENGTH_SHORT).show();
        });
        root.addView(test);

        setContentView(root);
    }

    private void saveSettings() {
        getSharedPreferences(PaymentForwarder.PREFS, MODE_PRIVATE)
                .edit()
                .putString(PaymentForwarder.KEY_URL, urlInput.getText().toString().trim())
                .putString(PaymentForwarder.KEY_SECRET, secretInput.getText().toString().trim())
                .apply();
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
    }

    private void requestSmsPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 100);
        }
    }
}
