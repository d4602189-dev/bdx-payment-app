package com.sohag.paymentforwarder;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class PaymentForwarder {
    public static final String PREFS = "payment_forwarder";
    public static final String KEY_URL = "bridge_url";
    public static final String KEY_SECRET = "bridge_secret";
    private static final String TAG = "PaymentForwarder";

    public static void send(Context context, String sender, String message) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String bridgeUrl = prefs.getString(KEY_URL, "").trim();
        String secret = prefs.getString(KEY_SECRET, "").trim();
        if (bridgeUrl.isEmpty() || secret.isEmpty()) {
            Log.w(TAG, "Bridge URL or secret is empty.");
            return;
        }
        new Thread(() -> post(bridgeUrl, secret, sender, message)).start();
    }

    private static void post(String bridgeUrl, String secret, String sender, String message) {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(bridgeUrl);
            String body = "secret=" + enc(secret)
                    + "&sender=" + enc(sender)
                    + "&text=" + enc(message);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            byte[] bytes = body.getBytes("UTF-8");
            connection.setRequestProperty("Content-Length", String.valueOf(bytes.length));
            OutputStream out = connection.getOutputStream();
            out.write(bytes);
            out.flush();
            out.close();
            Log.i(TAG, "Sent SMS payment event. Response: " + connection.getResponseCode());
        } catch (Exception e) {
            Log.e(TAG, "Forward failed", e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private static String enc(String value) throws Exception {
        return URLEncoder.encode(value == null ? "" : value, "UTF-8");
    }
}
