ANDROID PAYMENT FORWARDER
=========================

Purpose:
This app reads incoming SMS on the Android phone and sends sender + SMS text to the bot payment bridge.
It is for Bkash/Nagad/Rocket auto verification.

Build:
1. Open this folder in Android Studio:
   android_payment_forwarder
2. Build APK.
3. Install APK on the phone that receives payment SMS.
4. Allow SMS permission.

App settings:
Bridge URL:
  http://YOUR_SERVER_IP:8790/sms

Secret:
  For central admin: copy from central payment bot /panel -> SMS App.
  For client owner: copy from Payment Gateway System -> App Secret.

Important:
- The phone and bot PC/server must be able to reach each other.
- Same Wi-Fi is easiest.
- If using a VPS, use the VPS public IP/domain.
- The app sends every incoming SMS to the bridge, but the bot only approves when TxID + amount match a pending request.
- If the SMS amount is lower than the user-submitted amount, the order is rejected.
- If the SMS amount is equal or higher, only the submitted amount is credited.
- A client owner secret can only sync that owner's own clients.
- Fake SMS protection depends on the real Android SMS sender address. Official Bkash/Nagad/Rocket sender names are accepted; personal numbers or unknown sender names are ignored.
